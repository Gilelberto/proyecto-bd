def add_depto(cursor):
    depto_no = input('Ingrese el número de departamento: ')
    depto_name = input('Ingrese el nombre del departamento: ')
    location = input('Ingrese la ubicación del departamento')
    params = (depto_no,depto_name,location)
    cursor.callproc("Add_depto",params)

def update_depto():
    print('update')
    pass

def delete_depto():
    print('delete')
    pass

def add_emp():
    print('add pero de emps')
    pass

def delete_emp():
    print('si')
    pass

def update_emp():
    print('no')
    pass

def noEmp_depto():
    print('a lo mejor')
    pass